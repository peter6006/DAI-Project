HybridServer
=================
Proyecto base para la realización de la práctica de la asignatura Desarrollo de Aplicaciones para Internet de la Escuela Superior de Ingeniría Informática de la Universidad de Vigo durante el curso 2014/2015.

----------------------
Autores - Grupo 1.1:
Pedro Ríos Fernández - 77012761K
Cibrán Fernández Núñez - 44663226D


Anotaciones:
El test "testInvalidXSLT" no funciona correctamente ya que todas las funciones de validar que intentamos usar no funcionaban correctamente, en el "if" de la linea 106, en la clase HTMLControllerDB, se deberia poner esa comprobacion. Actualmente en ese if esta la llamada a una funcion de validacion, pero con esta llamada, los test "testConvertedGet" de "ConvertedXMLTest" y "InvalidConvertedXMLTest" no devuelven lo esperado porque nunca entran en el "if", si la comprobacion de dicho "if" se cambia por true dichos test funcionan correctamente mientras que el "testInvalidXSLT" no.

Para que algunos test funcionasen fue necesario aumentar el tiempo de espera en los test.